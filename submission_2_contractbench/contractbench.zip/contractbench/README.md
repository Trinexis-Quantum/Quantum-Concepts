# ContractBench

**Does a repair agent follow the engineering contract that was in force when the issue was filed?**

A patch can pass its tests and still violate the requirement that governed the code on the task date. In ContractBench every task comes in a **pair**: one codebase and one issue text, but two engineering contracts written as dated ADR documents, where a later ADR supersedes an earlier one. The task dated before the revision needs contract 0, and the task dated after it needs contract 1. A patch that follows the wrong contract can look fine and pass generic tests, so it is scored separately as a **wrong-contract** patch.

- **240 pairs, 480 tasks, 20 function families.** Every pair is execution-validated: the legacy code fails both oracles, each reference patch passes its own oracle and fails the other's, and all pass the shared invariants.
- **An independent verifier.** It applies a patch to a fresh snapshot, overlays trusted oracle files after the patch so the grader cannot be edited, and runs pytest in a scrubbed subprocess.
- **Metrics.** pass@1, wrong-contract rate and **PCSR** (paired contract success rate: both sides of a pair solved for the same sample), with family-clustered bootstrap confidence intervals.
- **Built-in controls.** A time-agnostic index (`include_future=True` in `materialize`) and swapped-contract patches (`gold --swapped`) let you check that your scorer and your agent both respond to the contract.

Everything here is Apache 2.0. [`DATACARD.md`](DATACARD.md) documents composition, construction and scoring.

## Quick start

```bash
pip install -e .            # Python >= 3.10, pytest, pytest-timeout
python -m contractbench info
python -m contractbench show synth-expiry-00-v0      # issue + the files an agent may see
python -m contractbench selfcheck --limit 3          # reference patches resolve their tasks
python -m pytest tests                               # 9 unit tests
```

Check the scorer at both extremes:

```bash
python -m contractbench gold            --out gold.jsonl      # reference patches
python -m contractbench gold --swapped  --out swapped.jsonl   # the other version's reference
python -m contractbench evaluate gold.jsonl      --limit 4     # PCSR 1.0, wrong_contract 0.0
python -m contractbench evaluate swapped.jsonl   --limit 4     # PCSR 0.0, wrong_contract 1.0
```

## Evaluate your own agent

1. For each task id, give your agent `materialize(rec, version, dest)` (the snapshot visible at that task's date, with no oracle files) plus `Task.issue`.
2. Write one JSON line per rollout: `{"task_id": "synth-expiry-00-v0", "sample": 0, "response": "<<<<<<< SEARCH path ..."}`.
3. Run `python -m contractbench evaluate preds.jsonl [--lenient] --out scored.jsonl`.

The strict parser needs `<<<<<<< SEARCH <path>` / `=======` / `>>>>>>> REPLACE` blocks. `--lenient` also accepts `SEARCH:` and infers a missing path when the SEARCH text occurs in exactly one non-test `.py` file. Strict measures edit-format compliance and lenient measures repair ability, so the reference runs report both (time-valid evidence arm: PCSR 0.428 strict, 0.789 lenient).

## Splits

`data/splits.json` defines 5 `train` families (used to train the adapters in the paper), 5 `test_original` and 10 `test_added` families. Compare with the published baselines on `heldout_eval`, the 15 test families. The data file contains the oracles and reference implementations, so keep them away from the agent you evaluate.

## Reference results (Gemma 4 12B, local)

Copied from the run in [`baselines/BASELINES.md`](baselines/BASELINES.md). The agent harness that produced them is part of the companion paper's repository.

| arm | what the agent gets | PCSR (lenient) | wrong-contract rate |
|---|---|---|---|
| B0 | tools only | 0.606 | 0.008 |
| B1 | + structural retrieval and call graph | 0.750 | 0.006 |
| **B2** | **+ time-valid decision records** | **0.789** | **0.000** |
| B2s | same records, time-agnostic index | 0.200 | 0.294 |
| B2x | same records, validity flags swapped | 0.111 | 0.403 |

60 pairs from 5 held-out families, 360 rollouts per arm.

| contrast | PCSR difference | 95% CI (family-clustered) | scope |
|---|---|---|---|
| time-valid evidence (B2) over time-agnostic index (B2s) | +0.589 | [0.306, 0.844] | 60 pairs, 5 families |
| same | +0.621 | [0.469, 0.759] | 180 pairs, 15 families |
| time-valid evidence (B2) over swapped flags (B2x) | +0.678 | [0.333, 0.917] | 60 pairs, 5 families |
| same | +0.643 | [0.479, 0.790] | 180 pairs, 15 families |
| time-valid evidence (B2) over tools only (B0) | +0.183 | [0.011, 0.333] | 60 pairs, 5 families |

Removing or inverting the validity markers moves PCSR by more than 0.6, and the controls produce well-formed patches (about 98% apply) for the wrong version. ContractBench therefore separates an agent that reads the contract in force from one that only writes plausible code.

## Safety note

The verifier uses process-level isolation: scrubbed environment, its own process group, CPU, memory and file-size limits, and a wall timeout. Run untrusted model output inside a container or VM.

## Citation

Vijayakumar, S. and Sidharth E. *CoEvoGraph-SWE: Co-Evolving Knowledge Graphs and Counterfactual World Models for Repository Repair.* Gemma 4 Developer Agent Paper Track, 2026.
