import json
import tempfile
from pathlib import Path

import pytest

from contractbench import load_pairs, load_tasks, make_task, materialize, paired_diff, summarize, verify_patch
from contractbench.__main__ import gold_response
from contractbench.edits import apply_edits, parse_lenient, parse_strict

PAIRS = load_pairs()
FIRST = next(iter(PAIRS.values()))


def test_dataset_shape():
    tasks = load_tasks()
    assert len(PAIRS) == 240 and len(tasks) == 480
    assert len({r["family"] for r in PAIRS.values()}) == 20
    assert all(r["validation"]["valid"] for r in PAIRS.values())


def test_snapshot_is_time_valid():
    with tempfile.TemporaryDirectory() as d0, tempfile.TemporaryDirectory() as d1:
        materialize(FIRST, 0, Path(d0))
        materialize(FIRST, 1, Path(d1))
        adr0 = {p.name for p in (Path(d0) / "docs/adr").glob("ADR-0*-" + FIRST["family"] + ".md")}
        adr1 = {p.name for p in (Path(d1) / "docs/adr").glob("ADR-0*-" + FIRST["family"] + ".md")}
        assert not any(n.startswith("ADR-021") for n in adr0)
        assert any(n.startswith("ADR-021") for n in adr1)
        assert not list(Path(d0).rglob("oracle_*"))


def test_strict_and_lenient_parsing():
    strict = "<<<<<<< SEARCH a/b.py\nold\n=======\nnew\n>>>>>>> REPLACE"
    assert parse_strict(strict) == [("a/b.py", "old", "new")]
    colon = "<<<<<<< SEARCH: a/b.py\nold\n=======\nnew\n>>>>>>> REPLACE"
    assert parse_strict(colon) == []
    with tempfile.TemporaryDirectory() as d:
        (Path(d) / "m.py").write_text("x = old_value\n")
        (Path(d) / "other.py").write_text("y = 1\n")
        pathless = "<<<<<<< SEARCH\nold_value\n=======\nnew_value\n>>>>>>> REPLACE"
        assert parse_lenient(pathless, Path(d)) == [("m.py", "old_value", "new_value")]
        (Path(d) / "dup.py").write_text("old_value\n")
        assert parse_lenient(pathless, Path(d)) is None


def test_protected_paths_and_ambiguous_matches_rejected():
    with tempfile.TemporaryDirectory() as d:
        (Path(d) / "tests").mkdir()
        (Path(d) / "tests/test_x.py").write_text("a\n")
        (Path(d) / "m.py").write_text("a\na\n")
        assert "protected" in apply_edits(Path(d), [("tests/test_x.py", "a", "b")]).error
        assert "matched 2" in apply_edits(Path(d), [("m.py", "a", "b")]).error
        assert "illegal" in apply_edits(Path(d), [("../m.py", "a", "b")]).error
        assert apply_edits(Path(d), []).error == "no edit blocks found"


@pytest.mark.parametrize("version", [0, 1])
def test_reference_resolves_and_swapped_is_wrong_contract(version):
    task = make_task(FIRST, version)
    good = verify_patch(FIRST, task, gold_response(FIRST, version))
    assert good.resolved and not good.wrong_contract
    wrong = verify_patch(FIRST, task, gold_response(FIRST, version, swapped=True))
    assert wrong.applied and not wrong.resolved and wrong.wrong_contract


def test_patch_cannot_modify_oracles():
    task = make_task(FIRST, 0)
    res = verify_patch(FIRST, task, "<<<<<<< SEARCH tests/oracle_contract0.py\nx\n=======\ny\n>>>>>>> REPLACE")
    assert not res.applied and "protected" in res.apply_error


def _row(pid, fam, version, resolved, sample=0):
    return {"pair_id": pid, "family": fam, "version": version, "sample": sample, "resolved": resolved,
            "wrong_contract": 0, "applied": 1}


def test_pcsr_requires_both_sides_per_sample():
    rows = [_row("p1", "f1", 0, 1), _row("p1", "f1", 1, 1),
            _row("p2", "f2", 0, 1), _row("p2", "f2", 1, 0),
            _row("p3", "f3", 0, 1)]
    s = summarize(rows)
    assert s["n_pairs"] == 2 and s["PCSR"] == 0.5


def test_paired_diff_uses_common_pairs():
    a = [_row("p1", "f1", 0, 1), _row("p1", "f1", 1, 1), _row("p2", "f2", 0, 1), _row("p2", "f2", 1, 1)]
    b = [_row("p1", "f1", 0, 1), _row("p1", "f1", 1, 0), _row("p2", "f2", 0, 0), _row("p2", "f2", 1, 0)]
    d = paired_diff(a, b)
    assert d["diff"] == 1.0 and d["n_pairs"] == 2 and d["n_families"] == 2
