"""SEARCH/REPLACE edit parsing and atomic application."""
from __future__ import annotations

import difflib
import re
from dataclasses import dataclass, field
from pathlib import Path

STRICT_RE = re.compile(
    r"<<<<<<< SEARCH (?P<path>[^\n]+)\n(?P<old>.*?)\n?=======\n(?P<new>.*?)\n?>>>>>>> REPLACE", re.DOTALL)
LENIENT_RE = re.compile(
    r"<<<<<<< SEARCH:?[ \t]*(?P<path>[^\n]*)\n(?P<old>.*?)\n?=======\n(?P<new>.*?)\n?>>>>>>> REPLACE", re.DOTALL)
TEST_PATH_RE = re.compile(r"(^|/)(tests?|testing)/|(^|/)test_[^/]*\.py$|_test\.py$|(^|/)conftest\.py$")

Edit = tuple[str, str, str]


@dataclass
class PatchResult:
    ok: bool
    error: str = ""
    touched: list[str] = field(default_factory=list)
    unified_diff: str = ""


def parse_strict(text: str) -> list[Edit]:
    """Blocks of the form ``<<<<<<< SEARCH <path>`` ... ``=======`` ... ``>>>>>>> REPLACE``."""
    return [(m["path"].strip(), m["old"], m["new"]) for m in STRICT_RE.finditer(text)]


def parse_lenient(text: str, workdir: Path) -> list[Edit] | None:
    """Like strict, but accepts ``SEARCH:`` and infers a missing path.

    A missing path is inferred only when the SEARCH text occurs in exactly one non-test ``.py`` file of
    ``workdir``; otherwise the response is rejected (``None``). Only parsing is relaxed, never the verdict.
    """
    blocks = list(LENIENT_RE.finditer(text))
    if not blocks:
        return None
    edits: list[Edit] = []
    pys: list[Path] | None = None
    for m in blocks:
        given = m["path"].strip()
        if given:
            edits.append((given, m["old"], m["new"]))
            continue
        if pys is None:
            pys = [p for p in workdir.rglob("*.py") if not TEST_PATH_RE.search(str(p.relative_to(workdir)))]
        hit = [p for p in pys if p.read_text(encoding="utf-8", errors="ignore").count(m["old"]) == 1]
        if len(hit) != 1:
            return None
        edits.append((str(hit[0].relative_to(workdir)), m["old"], m["new"]))
    return edits


def apply_edits(workdir: Path, edits: list[Edit]) -> PatchResult:
    """Apply edits atomically; reject test paths, escaping paths, and ambiguous or missing matches."""
    if not edits:
        return PatchResult(False, "no edit blocks found")
    originals: dict[str, str] = {}
    updated: dict[str, str] = {}
    for rel, old, new in edits:
        rel = rel.strip().removeprefix("./")
        if ".." in Path(rel).parts or Path(rel).is_absolute():
            return PatchResult(False, f"illegal path {rel}")
        if TEST_PATH_RE.search(rel) or rel.startswith("tests/"):
            return PatchResult(False, f"edit touches protected test path {rel}")
        path = workdir / rel
        if rel not in updated:
            if not path.is_file():
                return PatchResult(False, f"file not found: {rel}")
            originals[rel] = updated[rel] = path.read_text(encoding="utf-8")
        if old.strip() == "":
            return PatchResult(False, "empty SEARCH block")
        count = updated[rel].count(old)
        if count != 1:
            return PatchResult(False, f"SEARCH block matched {count} times in {rel}")
        updated[rel] = updated[rel].replace(old, new, 1)
    diff = ""
    for rel, text in updated.items():
        (workdir / rel).write_text(text, encoding="utf-8")
        diff += "".join(difflib.unified_diff(originals[rel].splitlines(True), text.splitlines(True), f"a/{rel}", f"b/{rel}"))
    return PatchResult(True, "", sorted(updated), diff)
