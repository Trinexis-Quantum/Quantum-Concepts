"""Task loading for ContractBench: pairs, tasks, visible workspaces and trusted oracle files."""
from __future__ import annotations

import json
from dataclasses import dataclass, field
from pathlib import Path

DATA_DIR = Path(__file__).resolve().parent.parent / "data"
SYNTHETIC_PATH = DATA_DIR / "synthetic_pairs.jsonl"


@dataclass
class Task:
    """One side (version 0 or 1) of a contract pair."""

    task_id: str
    pair_id: str
    version: int
    family: str
    issue: str
    cutoff: str
    target_file: str
    oracle_own: str
    oracle_other: str
    oracle_invariants: list[str] = field(default_factory=list)


def load_pairs(path: Path | str = SYNTHETIC_PATH) -> dict[str, dict]:
    """Return ``{pair_id: record}`` for every synthetic pair."""
    pairs: dict[str, dict] = {}
    with open(path, encoding="utf-8") as f:
        for line in f:
            rec = json.loads(line)
            pairs[rec["pair_id"]] = rec
    return pairs


def make_task(rec: dict, version: int) -> Task:
    own, other = f"contract{version}", f"contract{1 - version}"
    return Task(
        task_id=f"{rec['pair_id']}-v{version}", pair_id=rec["pair_id"], version=version, family=rec["family"],
        issue=rec["issue"], cutoff=rec["cutoffs"][version], target_file=rec["target_file"],
        oracle_own=f"tests/oracle_{own}.py", oracle_other=f"tests/oracle_{other}.py",
        oracle_invariants=["tests/oracle_invariants.py", "tests/test_service.py", "tests/test_report.py"])


def load_tasks(path: Path | str = SYNTHETIC_PATH) -> list[Task]:
    """Both sides of every pair, ordered by pair then version."""
    return [make_task(rec, v) for rec in load_pairs(path).values() for v in (0, 1)]


def materialize(rec: dict, version: int, dest: Path, include_future: bool = False) -> None:
    """Write the repository snapshot visible at the cutoff of ``version`` into ``dest``.

    The snapshot has no oracle files. ``include_future=True`` builds the time-agnostic snapshot
    (every ADR and the latest changelog regardless of the task date), used for leakage controls.
    """
    files = dict(rec["files_common"])
    files[rec["target_file"]] = rec["core"]["legacy"]
    for name, (_date, text) in rec["adr"].items():
        is_future = name == "ADR-021" and version == 0
        if include_future or not is_future:
            files[f"docs/adr/{name}-{rec['family']}.md"] = text
    files["docs/CHANGELOG.md"] = rec["changelog"][1 if (version == 1 or include_future) else 0]
    for rel, text in files.items():
        path = dest / rel
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(text, encoding="utf-8")


def oracle_files(rec: dict) -> dict[str, str]:
    """Trusted oracle files (path -> text), overlaid after the candidate patch is applied."""
    return {f"tests/oracle_{name}.py": text for name, text in rec["oracles"].items()}
