"""Command line: ``python -m contractbench {info,show,gold,selfcheck,evaluate}``."""
from __future__ import annotations

import argparse
import json
import sys
import tempfile
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

from .data import SYNTHETIC_PATH, load_pairs, make_task, materialize
from .metrics import summarize
from .verify import verify_patch


def _block(path: str, old: str, new: str) -> str:
    return f"<<<<<<< SEARCH {path}\n{old}\n=======\n{new}\n>>>>>>> REPLACE\n"


def gold_response(rec: dict, version: int, swapped: bool = False) -> str:
    """Reference patch as a model-style response. ``swapped=True`` writes the OTHER version's reference."""
    impl = f"c{1 - version if swapped else version}"
    return _block(rec["target_file"], rec["core"]["legacy"].rstrip("\n"), rec["core"][impl].rstrip("\n"))


def cmd_info(args) -> None:
    pairs = load_pairs(args.data)
    fams: dict[str, int] = {}
    for r in pairs.values():
        fams[r["family"]] = fams.get(r["family"], 0) + 1
    print(f"pairs: {len(pairs)}  tasks: {2 * len(pairs)}  families: {len(fams)}")
    for f, n in sorted(fams.items()):
        print(f"  {f:12s} {n} pairs")


def cmd_show(args) -> None:
    pairs = load_pairs(args.data)
    pid, v = args.task_id.rsplit("-v", 1)
    rec, task = pairs[pid], make_task(pairs[pid], int(v))
    print(f"task {task.task_id}  family={task.family}  cutoff={task.cutoff}\n\nISSUE: {task.issue}\n")
    with tempfile.TemporaryDirectory() as d:
        materialize(rec, task.version, Path(d))
        for p in sorted(Path(d).rglob("*")):
            if p.is_file():
                print(" ", p.relative_to(d))


def cmd_gold(args) -> None:
    out = open(args.out, "w") if args.out else sys.stdout
    for rec in load_pairs(args.data).values():
        for v in (0, 1):
            out.write(json.dumps({"task_id": f"{rec['pair_id']}-v{v}", "sample": 0,
                                  "response": gold_response(rec, v, args.swapped)}) + "\n")


def _score(pairs: dict, task_id: str, response: str, lenient: bool) -> dict:
    pid, v = task_id.rsplit("-v", 1)
    rec, task = pairs[pid], make_task(pairs[pid], int(v))
    cert = verify_patch(rec, task, response, lenient=lenient)
    return {"task_id": task_id, "pair_id": pid, "family": rec["family"], "version": int(v), "resolved": cert.resolved,
            "wrong_contract": cert.wrong_contract, "applied": cert.applied, "cert": cert.to_dict()}


def evaluate(pred_path: str, data: Path, lenient: bool, jobs: int, limit: int | None = None) -> list[dict]:
    pairs = load_pairs(data)
    preds = [json.loads(l) for l in open(pred_path, encoding="utf-8") if l.strip()]
    if limit:
        keep = set(list(pairs)[:limit])
        preds = [p for p in preds if p["task_id"].rsplit("-v", 1)[0] in keep]
    with ThreadPoolExecutor(jobs) as ex:
        rows = list(ex.map(lambda p: {**_score(pairs, p["task_id"], p["response"], lenient), "sample": p.get("sample", 0)}, preds))
    return rows


def cmd_evaluate(args) -> None:
    rows = evaluate(args.predictions, args.data, args.lenient, args.jobs, args.limit)
    if args.out:
        with open(args.out, "w") as f:
            for r in rows:
                f.write(json.dumps(r) + "\n")
    print(json.dumps({k: (round(v, 3) if isinstance(v, float) else v) for k, v in summarize(rows).items()}, indent=2))


def cmd_selfcheck(args) -> None:
    """Benchmark integrity: the matching reference must resolve each task; the other version's reference must be a wrong-contract patch."""
    pairs = load_pairs(args.data)
    ids = list(pairs)[: args.limit] if args.limit else list(pairs)
    bad = 0
    for pid in ids:
        rec = pairs[pid]
        for v in (0, 1):
            task = make_task(rec, v)
            good = verify_patch(rec, task, gold_response(rec, v))
            wrong = verify_patch(rec, task, gold_response(rec, v, swapped=True))
            ok = good.resolved and not good.wrong_contract and wrong.wrong_contract and not wrong.resolved
            if not ok:
                bad += 1
                print(f"FAIL {task.task_id}: gold resolved={good.resolved}, swapped wrong_contract={wrong.wrong_contract}")
    print(f"selfcheck: {2 * len(ids)} tasks, {bad} failures")
    sys.exit(1 if bad else 0)


def main(argv: list[str] | None = None) -> None:
    ap = argparse.ArgumentParser(prog="contractbench", description=__doc__)
    ap.add_argument("--data", type=Path, default=SYNTHETIC_PATH)
    sub = ap.add_subparsers(dest="cmd", required=True)
    sub.add_parser("info").set_defaults(fn=cmd_info)
    s = sub.add_parser("show"); s.add_argument("task_id"); s.set_defaults(fn=cmd_show)
    g = sub.add_parser("gold"); g.add_argument("--out"); g.add_argument("--swapped", action="store_true", help="emit the other version's reference (wrong-contract patches)"); g.set_defaults(fn=cmd_gold)
    c = sub.add_parser("selfcheck"); c.add_argument("--limit", type=int); c.set_defaults(fn=cmd_selfcheck)
    e = sub.add_parser("evaluate"); e.add_argument("predictions"); e.add_argument("--lenient", action="store_true"); e.add_argument("--jobs", type=int, default=4); e.add_argument("--limit", type=int, help="first N pairs only"); e.add_argument("--out"); e.set_defaults(fn=cmd_evaluate)
    args = ap.parse_args(argv)
    args.fn(args)


if __name__ == "__main__":
    main()
