"""Metrics: pass@1, wrong-contract rate, PCSR and family-clustered bootstrap confidence intervals.

PCSR (paired contract success rate): a pair counts as solved for sample index ``s`` when the version-0 rollout
AND the version-1 rollout with the same ``s`` both resolve their tasks. Confidence intervals resample whole
families (never individual rollouts), because pairs inside a family share code and contracts.
"""
from __future__ import annotations

import random
from collections import defaultdict
from statistics import mean


def pair_level(rows: list[dict]) -> dict[str, dict]:
    """``{pair_id: {"family", "pcsr", "v0", "v1"}}`` averaged over samples; pairs missing a side are dropped."""
    by: dict[tuple[str, int], dict[int, int]] = defaultdict(dict)
    fam: dict[str, str] = {}
    for r in rows:
        by[(r["pair_id"], r.get("sample", 0))][r["version"]] = int(r["resolved"])
        fam[r["pair_id"]] = r["family"]
    acc: dict[str, list[tuple[int, int]]] = defaultdict(list)
    for (pid, _s), sides in by.items():
        if 0 in sides and 1 in sides:
            acc[pid].append((sides[0], sides[1]))
    return {pid: {"family": fam[pid], "pcsr": mean(a * b for a, b in v), "v0": mean(a for a, _ in v),
                  "v1": mean(b for _, b in v)} for pid, v in acc.items()}


def cluster_bootstrap(values: dict[str, tuple[str, float]], n: int = 4000, seed: int = 0) -> tuple[float, float]:
    """95% CI of the mean of ``{pair_id: (family, value)}`` resampling families."""
    groups: dict[str, list[float]] = defaultdict(list)
    for fam, val in values.values():
        groups[fam].append(val)
    fams = list(groups)
    rng = random.Random(seed)
    boots = []
    for _ in range(n):
        pick = [rng.choice(fams) for _ in fams]
        flat = [v for f in pick for v in groups[f]]
        boots.append(sum(flat) / len(flat))
    boots.sort()
    return boots[int(0.025 * n)], boots[min(n - 1, int(0.975 * n))]


def summarize(rows: list[dict]) -> dict:
    """Headline numbers for one set of verified rollouts (each row: pair_id, family, version, sample, resolved, ...)."""
    pl = pair_level(rows)
    lo, hi = cluster_bootstrap({p: (d["family"], d["pcsr"]) for p, d in pl.items()}) if pl else (float("nan"),) * 2
    return {
        "n_rollouts": len(rows),
        "n_pairs": len(pl),
        "pass@1": mean(int(r["resolved"]) for r in rows) if rows else float("nan"),
        "PCSR": mean(d["pcsr"] for d in pl.values()) if pl else float("nan"),
        "PCSR_lo": lo,
        "PCSR_hi": hi,
        "wrong_contract": mean(int(r["wrong_contract"]) for r in rows) if rows else float("nan"),
        "applied": mean(int(r["applied"]) for r in rows) if rows else float("nan"),
    }


def paired_diff(rows_a: list[dict], rows_b: list[dict], n: int = 4000, seed: int = 0) -> dict:
    """PCSR(A) - PCSR(B) on pairs present in both, with a family-clustered bootstrap CI."""
    a, b = pair_level(rows_a), pair_level(rows_b)
    common = a.keys() & b.keys()
    diffs = {p: (a[p]["family"], a[p]["pcsr"] - b[p]["pcsr"]) for p in common}
    lo, hi = cluster_bootstrap(diffs, n, seed) if diffs else (float("nan"),) * 2
    return {"diff": mean(v for _, v in diffs.values()) if diffs else float("nan"), "ci_lo": lo, "ci_hi": hi,
            "n_pairs": len(diffs), "n_families": len({f for f, _ in diffs.values()})}
