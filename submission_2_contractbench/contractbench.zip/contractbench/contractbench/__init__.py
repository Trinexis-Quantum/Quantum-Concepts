"""ContractBench: does a repair agent follow the engineering contract in force at the task date?"""
from .data import Task, load_pairs, load_tasks, make_task, materialize, oracle_files
from .metrics import pair_level, paired_diff, summarize
from .verify import Certificate, verify_patch

__version__ = "0.1.0"
__all__ = ["Task", "load_pairs", "load_tasks", "make_task", "materialize", "oracle_files", "pair_level",
           "paired_diff", "summarize", "Certificate", "verify_patch"]
