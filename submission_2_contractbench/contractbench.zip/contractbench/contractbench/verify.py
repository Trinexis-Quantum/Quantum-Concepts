"""Independent verifier: apply a patch to a fresh snapshot, overlay trusted oracles, run pytest.

Isolation is process-level only (scrubbed environment, own process group, CPU/memory/file-size limits, wall
timeout). It is NOT a container: run untrusted model output inside a container or VM if that matters to you.
"""
from __future__ import annotations

import hashlib
import json
import os
import resource
import shutil
import subprocess
import sys
import tempfile
import time
import xml.etree.ElementTree as ET
from dataclasses import dataclass, field
from pathlib import Path

from .data import Task, materialize, oracle_files
from .edits import Edit, apply_edits, parse_lenient, parse_strict


def sha256_text(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def _limits(cpu_seconds: int):
    def apply() -> None:
        os.setsid()
        resource.setrlimit(resource.RLIMIT_CPU, (cpu_seconds, cpu_seconds + 5))
        resource.setrlimit(resource.RLIMIT_AS, (4 << 30, 4 << 30))
        resource.setrlimit(resource.RLIMIT_FSIZE, (64 << 20, 64 << 20))
    return apply


def run_pytest(workdir: Path, targets: list[str], timeout: int = 60, per_test_timeout: int = 30) -> dict[str, str]:
    """Run pytest on ``targets`` inside ``workdir``; return ``{classname::name: status}`` from the JUnit report."""
    xml_path = workdir / ".cb_junit.xml"
    home = workdir / ".cb_home"
    home.mkdir(exist_ok=True)
    env = {"PATH": "/usr/bin:/bin", "HOME": str(home), "PYTHONPATH": str(workdir), "PYTHONDONTWRITEBYTECODE": "1",
           "PYTHONHASHSEED": "0", "TZ": "UTC", "LC_ALL": "C.UTF-8"}
    cmd = [sys.executable, "-m", "pytest", "-p", "no:cacheprovider", "-o", "addopts=", f"--timeout={per_test_timeout}",
           f"--junitxml={xml_path}", "-q", "--tb=no", "--rootdir", str(workdir), *targets]
    proc = subprocess.Popen(cmd, cwd=workdir, env=env, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True,
                            preexec_fn=_limits(timeout))
    try:
        proc.communicate(timeout=timeout)
    except subprocess.TimeoutExpired:
        try:
            os.killpg(proc.pid, 9)
        except ProcessLookupError:
            pass
        proc.communicate()
        return {}
    outcomes: dict[str, str] = {}
    if xml_path.exists():
        try:
            tree = ET.parse(xml_path)
        except ET.ParseError:
            return {}
        for case in tree.iter("testcase"):
            status = "pass"
            for child in case:
                if child.tag == "failure":
                    status = "fail"
                elif child.tag == "error":
                    status = "error"
                elif child.tag == "skipped":
                    status = "skip"
            outcomes[f"{case.get('classname', '')}::{case.get('name', '')}"] = status
    return outcomes


def _ok(outcomes: dict[str, str]) -> bool:
    return bool(outcomes) and not any(s in ("fail", "error") for s in outcomes.values())


@dataclass
class Certificate:
    """Evidence for one candidate patch."""

    task_id: str
    patch_sha256: str
    applied: bool
    apply_error: str = ""
    own_pass: bool = False
    invariants_pass: bool = False
    other_contract_pass: bool = False
    touched: list[str] = field(default_factory=list)
    oracle_sha256: dict[str, str] = field(default_factory=dict)
    seconds: float = 0.0

    @property
    def resolved(self) -> bool:
        return self.applied and self.own_pass and self.invariants_pass

    @property
    def wrong_contract(self) -> bool:
        """The patch fails the task's own contract while satisfying the other version's contract."""
        return self.applied and not self.own_pass and self.other_contract_pass

    def to_dict(self) -> dict:
        return {**self.__dict__, "resolved": self.resolved, "wrong_contract": self.wrong_contract}


def verify_patch(rec: dict, task: Task, patch: "str | list[Edit]", lenient: bool = False) -> Certificate:
    """Score ``patch`` (model response text, or a parsed edit list) on one side of a pair."""
    t0 = time.time()
    work = Path(tempfile.mkdtemp(prefix="contractbench_"))
    try:
        materialize(rec, task.version, work)
        if isinstance(patch, str):
            patch_hash = sha256_text(patch)
            edits = parse_strict(patch) or (parse_lenient(patch, work) if lenient else None)
            edits = edits or []
        else:
            edits, patch_hash = patch, sha256_text(json.dumps(patch))
        res = apply_edits(work, edits)
        if not res.ok:
            return Certificate(task.task_id, patch_hash, False, res.error, seconds=time.time() - t0)
        hashes = {}
        for rel, text in oracle_files(rec).items():
            (work / rel).parent.mkdir(parents=True, exist_ok=True)
            (work / rel).write_text(text, encoding="utf-8")
            hashes[rel] = sha256_text(text)
        own = _ok(run_pytest(work, [task.oracle_own]))
        inv = _ok(run_pytest(work, task.oracle_invariants))
        other = _ok(run_pytest(work, [task.oracle_other]))
        return Certificate(task.task_id, patch_hash, True, "", own, inv, other, res.touched, hashes, time.time() - t0)
    finally:
        shutil.rmtree(work, ignore_errors=True)
