# ContractGate

**A pre-execution check that asks: does this patch follow the engineering contract that was in force on the task date?**

Teams revise requirements: a token lifetime moves from 45 seconds to 75, a discount rule changes. A patch for the old rule can look correct, pass generic tests, and still be wrong for a ticket filed after the revision. ContractGate scores a candidate patch against the contract in force *before any test is run*, using three things:

1. **Time-valid evidence.** Dated ADR documents in the repository are parsed. Anything dated after the task date is invisible, and an ADR already superseded by an on-time revision is marked as such. The tool reports which ADR governs the patched function and which one it replaced.
2. **A code graph.** Callers and tests of the patched function (CALLS and TESTS edges) give the blast radius.
3. **The C3-GWM world model.** A small gradient-boosted model predicts P(patch resolves the task) from the diff, the contract text and the graph counts. The features are structural, hashed added-line tokens, and contract-conditioned overlap with the governing and the superseded contract.

It answers **accept**, **flag** or **abstain** (no dated ADR applies to that function, so it does not guess). P(resolved) is the quantity to use for ranking candidate patches and for deciding which to review first; `--threshold` sets the accept cut-off for your deployment.

## Quick start

```bash
pip install -e .                  # numpy, scikit-learn, networkx, joblib
pip install -e ../contractbench   # only for the demo and tests (snapshots come from ContractBench)

python -m contractgate demo                     # worked example, family held out of training
python -m contractgate evaluate                 # leave-families-out reproduction of the paper's world-model test (~20 s)
python -m contractgate evaluate --new-families  # out-of-family test on 10 families never used (~20 s)
python -m pytest tests                          # 10 tests, ~25 s
```

Assess your own patch (the repository needs dated ADRs, see "Input format"):

```bash
python -m contractgate assess --repo path/to/snapshot --date 2026-05-19 \
    --file billing/core.py --func decide_expiry --patch edits.txt     # SEARCH/REPLACE blocks, or --new-file path
```

Output of `python -m contractgate demo` (task `synth-expiry-00-v1`, dated after ADR-021; the gate was trained without the `expiry` family):

```
  [fix that follows the contract in force]
decision: ACCEPT   P(resolved)=0.943  (threshold 0.5)
  in force   ADR-021 (2026-05-18): ... Access tokens now expire after 75 seconds. ...
  superseded ADR-010 (2026-02-02): Access tokens expire 45 seconds after issue. ...
  [fix that follows the OTHER (wrong) contract]
decision: FLAG   P(resolved)=0.003  (threshold 0.5)
  - patch introduces values that appear only in the superseded contract: ['45']
```

The fix that follows the contract in force is accepted at 0.943, and the fix for the superseded contract is flagged at 0.003 with a reason a reviewer can act on.

## Input format

The tool reads the convention used in ContractBench: `docs/adr/ADR-NNN-*.md` with a `# ADR-NNN title` heading, a `Date: YYYY-MM-DD` line, an `Applies to: \`path/to/file.py\` (\`function\`)` line, and wording such as "revises ADR-010" or "supersedes ADR-010" for revisions. A function with no applicable dated ADR gets **abstain**.

## Evaluation

Labels come from executing every candidate patch with a verifier; nothing is labelled by an LLM. Candidates per task are the own-contract reference fix, the other contract's reference fix (a clean, plausible wrong-contract patch), a no-op and up to 24 mutants.

### A. Original 10 families, leave-families-out (6,480 patches)
Reproduces the paper's world-model result (`results/original_10_families_leave_family_out.txt`). Base rate resolved: 0.075.

| | AUPRC (resolved) | pairwise accuracy: right contract's fix scored above wrong contract's |
|---|---|---|
| B7 contract-blind | 0.217 [0.146, 0.294] | 0.500 (by construction) |
| **B8 C3-GWM (ContractGate)** | **0.410 [0.265, 0.569]** | **0.779 [0.629, 0.929]** |
| B8 with shuffled contracts (control) | 0.131 [0.092, 0.170] | 0.506 [0.487, 0.529] |

B8 minus B7 is +0.194 [0.114, 0.285] and B8 minus shuffled is +0.279 [0.151, 0.424]. Intervals are 95%, family-clustered bootstrap. The 0.500 is exact by construction: the two tasks of a pair swap which reference is right, and the contract-blind model scores a given patch identically in both.

### B. Ten unseen families (5,798 patches)
Trained on the 10 original families and tested on 10 families that no model or setting had seen (`results/unseen_10_families.txt`). Base rate resolved: 0.082.

| | AUPRC (resolved) | pairwise accuracy |
|---|---|---|
| B7 contract-blind | 0.361 [0.284, 0.430] | 0.500 (by construction) |
| **B8 C3-GWM (ContractGate)** | **0.504 [0.384, 0.615]** | **0.758 [0.613, 0.896]** |
| B8 with shuffled contracts (control) | 0.236 [0.188, 0.293] | 0.529 [0.496, 0.567] |

B8 minus B7 is +0.143 [0.040, 0.249] and B8 minus shuffled is +0.268 [0.167, 0.365]. The contract-conditioned advantage replicates out of family.

On half of the original families, and on half of the unseen ones, the right contract's fix is ranked above the wrong one in at least 96% of pairs (1.00 on five original families). Per-family tables are in `results/`.

### Verification of the packaging
- The tool's own contract and graph logic reproduces, for all 240 original tasks, the context the paper pipeline used: the same contract in force, the same superseded contract and the same caller and test counts (720 feature vectors compared, 0 differences).
- The ContractBench verifier that labelled the unseen families agrees with the original sandbox's recorded labels on 240 randomly chosen original patches (0 disagreements).
- `tests/` includes tests that fail if the numbers above drift (AUPRC within 0.01 of the published values).

## Intended use

- Rank candidate patches by P(resolved) before executing them, so the likeliest-correct patch is tried first and the likeliest-wrong ones get a reviewer's attention.
- Read the contract-in-force and superseded-contract lines in the output to see which requirement a patch is being judged against.
- Calibrate the accept threshold on your own data before using accept/flag as a hard decision. The tool ranks patches and complements running the tests; it is not a security control.
- Models are pickled with scikit-learn. If the installed version differs, the tool retrains from the shipped interventions in a few seconds.

## Provenance and license

`graph.py` is the paper repository's `coevo/kg.py` and `features.py` is its `coevo/worldmodel.py` (plus `tokenize` from `coevo/retrieval.py`), with only module-level changes. `artifacts/` holds executed-patch data exported by `scripts/` (the scripts need the paper repository). Apache 2.0, see `LICENSE`; third-party dependencies are in `THIRD_PARTY_NOTICES.md`.
