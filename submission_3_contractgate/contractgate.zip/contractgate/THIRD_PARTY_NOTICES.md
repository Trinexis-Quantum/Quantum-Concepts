# Third-party notices

ContractGate is released under the Apache License 2.0. It is installed alongside, and does not redistribute, the following packages.

| package | role | license |
|---|---|---|
| numpy | feature arrays | BSD-3-Clause |
| scikit-learn | gradient-boosted world model | BSD-3-Clause |
| networkx | code graph | BSD-3-Clause |
| joblib | model serialisation | BSD-3-Clause |
| pytest | tests (optional) | MIT |
| contractbench | snapshots for the demo and tests (optional) | Apache-2.0 |

`graph.py` and `features.py` are the authors' own modules from the CoEvoGraph-SWE repository (`coevo/kg.py` and `coevo/worldmodel.py`). `artifacts/` holds executed-patch data generated from ContractBench tasks and contains no third-party source code or personal data.
