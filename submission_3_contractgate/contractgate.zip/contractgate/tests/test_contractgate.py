import json
import sys
import tempfile
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[2] / "contractbench"))
cb = pytest.importorskip("contractbench")

from contractgate import apply_blocks, assess, contracts_for
from contractgate.graph import build_kg
from contractgate.model import ARTIFACTS, evaluate, evaluate_new_families, load_model, load_new_samples, load_samples

PAIRS = cb.load_pairs()
REC = next(iter(PAIRS.values()))          # synth-expiry-00 (ADR-010 -> ADR-021)
CTX = json.load(open(ARTIFACTS / "contexts.json"))


def _snapshot(version, include_future=False):
    d = tempfile.TemporaryDirectory()
    cb.materialize(REC, version, Path(d.name), include_future=include_future)
    return d


def test_contract_in_force_is_time_valid():
    with _snapshot(0, include_future=True) as d0, _snapshot(1) as d1:
        gov0, sup0 = contracts_for(build_kg(Path(d0)), "2026-02-03", REC["target_file"], REC["func"])
        gov1, sup1 = contracts_for(build_kg(Path(d1)), "2026-05-19", REC["target_file"], REC["func"])
    assert gov0.doc_id == "ADR-010" and sup0 == []        # ADR-021 exists in the snapshot but is dated after the task
    assert gov1.doc_id == "ADR-021" and [d.doc_id for d in sup1] == ["ADR-010"]


def test_context_matches_paper_pipeline_for_every_task():
    bad = []
    for pid, rec in PAIRS.items():
        for v in (0, 1):
            tid = f"{pid}-v{v}"
            if tid not in CTX:
                continue
            with tempfile.TemporaryDirectory() as d:
                cb.materialize(rec, v, Path(d))
                kg = build_kg(Path(d))
                gov, sup = contracts_for(kg, cb.make_task(rec, v).cutoff, rec["target_file"], rec["func"])
                target = next(n for n, i in kg.symbols.items() if i["name"] == rec["func"] and i["path"] == rec["target_file"])
                callers = kg.callers(target)
                tests = len({t for c in callers for t in kg.tests_of(c)} | set(kg.tests_of(target)))
            c = CTX[tid]
            if not (gov.text.strip() == c["gov"].strip() and "\n".join(x.text for x in sup).strip() == c["other"].strip()
                    and len(callers) == c["callers"] and tests == c["tests"]):
                bad.append(tid)
    assert not bad, bad[:5]


def test_abstains_without_contract_evidence():
    with _snapshot(1) as d:
        v = assess(d, "2026-05-19", REC["target_file"], "no_such_function", new_src="x = 1\n")
    assert v.decision == "abstain" and v.p_resolved is None


def test_abstains_before_any_adr_exists():
    with _snapshot(1) as d:
        v = assess(d, "2026-01-01", REC["target_file"], REC["func"], new_src="x = 1\n")
    assert v.decision == "abstain"


def test_assess_returns_calibrated_fields_and_evidence():
    model = load_model()
    with _snapshot(1) as d:
        new_src = (Path(d) / REC["target_file"]).read_text()
        v = assess(d, "2026-05-19", REC["target_file"], REC["func"], new_src=new_src, model=model)  # no-op patch
    assert v.decision in ("accept", "flag") and 0.0 <= v.p_resolved <= 1.0
    assert v.contract_in_force.adr_id == "ADR-021" and v.superseded[0].adr_id == "ADR-010"
    assert v.decision == "flag"                                   # a no-op must not be accepted


def test_apply_blocks_requires_unique_match():
    assert apply_blocks("a b a", "<<<<<<< SEARCH x.py\nb\n=======\nc\n>>>>>>> REPLACE") == "a c a"
    with pytest.raises(ValueError):
        apply_blocks("a b a", "<<<<<<< SEARCH x.py\na\n=======\nc\n>>>>>>> REPLACE")
    with pytest.raises(ValueError):
        apply_blocks("a", "no blocks")


def test_training_data_shape():
    s = load_samples()
    assert len(s) == 6480 and len({x.family for x in s}) == 10
    assert sum(x.labels["resolved"] for x in s) == 486


@pytest.mark.slow
def test_reproduces_published_world_model_numbers():
    r = evaluate(n_boot=200)
    a = r["auprc_resolved"]
    assert abs(a["B8"]["mean"] - 0.410) < 0.01 and abs(a["B7"]["mean"] - 0.217) < 0.01 and abs(a["B8-shuffled"]["mean"] - 0.131) < 0.01
    assert r["contract_choice_accuracy"]["B7"]["mean"] == 0.5
    assert r["contract_choice_accuracy"]["B8"]["lo"] > 0.5


def test_unseen_family_data_is_disjoint_from_training():
    new, old = load_new_samples(), load_samples()
    assert {s.family for s in new}.isdisjoint({s.family for s in old}) and len({s.family for s in new}) == 10
    assert len(new) == 5798 and sum(s.labels["resolved"] for s in new) == 478


@pytest.mark.slow
def test_unseen_families_result_is_stable():
    r = evaluate_new_families(n_boot=200)
    a = r["auprc_resolved"]
    assert abs(a["B8"]["mean"] - 0.504) < 0.01 and abs(a["B7"]["mean"] - 0.361) < 0.01 and abs(a["B8-shuffled"]["mean"] - 0.236) < 0.01
    assert r["B8_minus_B7"]["lo"] > 0 and r["contract_choice_accuracy"]["B8"]["lo"] > 0.5
