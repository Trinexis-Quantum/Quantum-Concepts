"""Execute candidate patches for the 10 families added after the paper's world-model data, with the ContractBench verifier.

Needs the paper repo (`coevo.wm_data.candidates` / `coevo.mutate`) and the `contractbench` package. Same protocol as the
original interventions: own reference, other-contract reference, no-op and 24 mutants per task (seed 11).
Usage (paper repo root, sandbox python): PYTHONPATH=.:submissions/contractbench .venv-sbx/bin/python <this file> [--crosscheck N]
"""
import gzip
import json
import random
import sys
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

import contractbench as cb
from coevo.wm_data import candidates

OUT = Path(__file__).resolve().parent.parent / "contractgate" / "artifacts"
NEW = open("data/tasks/new_families.txt").read().strip().split(",")
pairs = cb.load_pairs()


def label(args):
    rec, v, src = args
    task = cb.make_task(rec, v)
    c = cb.verify_patch(rec, task, [(rec["target_file"], rec["core"]["legacy"], src)])
    return {"own_pass": int(c.own_pass), "inv_pass": int(c.invariants_pass), "other_contract_pass": int(c.other_contract_pass), "applied": int(c.applied)}


if "--crosscheck" in sys.argv:
    n = int(sys.argv[sys.argv.index("--crosscheck") + 1])
    rows = [json.loads(l) for l in open("runs/wm_interventions.jsonl")]
    random.Random(0).shuffle(rows)
    rows = rows[:n]
    with ThreadPoolExecutor(8) as ex:
        got = list(ex.map(label, [(pairs[r["pair_id"]], r["version"], r["src"]) for r in rows]))
    diff = [(r["task_id"], r["origin"]) for r, g in zip(rows, got)
            if (g["own_pass"], g["inv_pass"], g["other_contract_pass"]) != (int(r["cert"]["own_pass"]), int(r["cert"]["p2p_pass"]), int(r["cert"]["other_contract_pass"]))]
    print(f"crosscheck: {n} original interventions re-labelled with the ContractBench verifier; label disagreements: {len(diff)}", diff[:5])
    sys.exit(0)

jobs = []
for rec in pairs.values():
    if rec["family"] in NEW:
        for v in (0, 1):
            for i, cand in enumerate(candidates(rec, v, 24, 11)):
                jobs.append((rec, v, i, cand))
print(len(jobs), "candidate patches to execute", flush=True)
with ThreadPoolExecutor(10) as ex:
    labels = list(ex.map(label, [(r, v, c["src"]) for r, v, _, c in jobs]))
with gzip.open(OUT / "new_family_interventions.jsonl.gz", "wt", encoding="utf-8") as f:
    for (rec, v, i, cand), lab in zip(jobs, labels):
        f.write(json.dumps({"task_id": f"{rec['pair_id']}-v{v}", "family": rec["family"], "origin": cand["origin"], "src": cand["src"],
                            "own_pass": lab["own_pass"], "inv_pass": lab["inv_pass"], "other_contract_pass": lab["other_contract_pass"]}) + "\n")
print("done", len(jobs))
