"""Export compact training data for the gate from the paper repository (needs the `coevo` package; not needed at runtime).

Usage (from the paper repo root): python submissions/contractgate/scripts/export_training_data.py
Writes contractgate/artifacts/{contexts.json,interventions.jsonl.gz}.
"""
import gzip
import json
from pathlib import Path

from coevo.tasks import TaskStore
from coevo.wm_eval import task_context

OUT = Path(__file__).resolve().parent.parent / "contractgate" / "artifacts"
store = TaskStore()
tasks = {t.task_id: t for t in store.tasks("synthetic")}
contexts, n = {}, 0
with gzip.open(OUT / "interventions.jsonl.gz", "wt", encoding="utf-8") as out:
    for line in open("runs/wm_interventions.jsonl"):
        r = json.loads(line)
        tid = r["task_id"]
        if tid not in contexts:
            c = task_context(store, tasks[tid])
            contexts[tid] = {"family": r["family"], "version": r["version"], **c}
        cert = r["cert"]
        out.write(json.dumps({"task_id": tid, "origin": r["origin"], "src": r["src"],
                              "own_pass": int(cert["own_pass"]), "inv_pass": int(cert["p2p_pass"]),
                              "other_contract_pass": int(cert["other_contract_pass"])}) + "\n")
        n += 1
json.dump(contexts, open(OUT / "contexts.json", "w"))
print(n, "interventions;", len(contexts), "tasks")
