"""Contract/graph context (via the gate's own logic) for the 10 added families. Needs `contractbench` for the snapshots."""
import json
import sys
import tempfile
from pathlib import Path

import contractbench as cb
from contractgate.gate import contracts_for
from contractgate.graph import build_kg

OUT = Path(__file__).resolve().parent.parent / "contractgate" / "artifacts"
NEW = set(open("data/tasks/new_families.txt").read().strip().split(","))
ctx = {}
for pid, rec in cb.load_pairs().items():
    if rec["family"] not in NEW:
        continue
    for v in (0, 1):
        task = cb.make_task(rec, v)
        with tempfile.TemporaryDirectory() as d:
            cb.materialize(rec, v, Path(d))
            kg = build_kg(Path(d))
            gov, sup = contracts_for(kg, task.cutoff, rec["target_file"], rec["func"])
            target = next(n for n, i in kg.symbols.items() if i["name"] == rec["func"] and i["path"] == rec["target_file"])
            callers = kg.callers(target)
            tests = len({t for c in callers for t in kg.tests_of(c)} | set(kg.tests_of(target)))
        assert gov is not None, task.task_id
        ctx[task.task_id] = {"family": rec["family"], "version": v, "legacy": rec["core"]["legacy"], "func": rec["func"],
                             "gov": gov.text, "other": "\n".join(d.text for d in sup), "callers": len(callers), "tests": tests}
json.dump(ctx, open(OUT / "new_contexts.json", "w"))
print(len(ctx), "tasks;", sorted({c["family"] for c in ctx.values()}))
