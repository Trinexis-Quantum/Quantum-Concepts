"""ContractGate: a pre-execution wrong-contract risk gate for patches, built on time-valid evidence and a code graph."""
from .gate import ContractEvidence, Verdict, apply_blocks, assess, contracts_for

__version__ = "0.1.0"
__all__ = ["ContractEvidence", "Verdict", "apply_blocks", "assess", "contracts_for"]
