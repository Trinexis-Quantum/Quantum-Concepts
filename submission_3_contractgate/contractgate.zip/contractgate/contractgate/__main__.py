"""Command line: ``python -m contractgate {assess,demo,evaluate,train}``."""
from __future__ import annotations

import argparse
import gzip
import json
import sys
import tempfile
from pathlib import Path

from .gate import assess
from .model import ARTIFACTS, evaluate, evaluate_new_families, load_model, save_model, train_full


def _show(v) -> None:
    print(f"decision: {v.decision.upper()}" + (f"   P(resolved)={v.p_resolved:.3f}  (threshold {v.threshold})" if v.p_resolved is not None else ""))
    if v.contract_in_force:
        e = v.contract_in_force
        print(f"  in force   {e.adr_id} ({e.date}): {e.summary}")
    for e in v.superseded:
        print(f"  superseded {e.adr_id} ({e.date}): {e.summary}")
    for r in v.reasons:
        print(f"  - {r}")


def cmd_assess(a) -> None:
    patch = Path(a.patch).read_text(encoding="utf-8") if a.patch else None
    new_src = Path(a.new_file).read_text(encoding="utf-8") if a.new_file else None
    v = assess(a.repo, a.date, a.file, a.func, new_src=new_src, patch=patch, threshold=a.threshold)
    print(json.dumps(v.to_dict(), indent=1) if a.json else "", end="")
    if not a.json:
        _show(v)


def cmd_train(a) -> None:
    save_model(train_full())
    print("saved", ARTIFACTS / "model.joblib")


def cmd_evaluate(a) -> None:
    r = evaluate_new_families() if a.new_families else evaluate()
    if a.out:
        Path(a.out).write_text(json.dumps(r, indent=1, default=float))
    f = lambda d: f"{d['mean']:.3f} [{d['lo']:.3f}, {d['hi']:.3f}]"  # noqa: E731
    print(f"{r['n_samples']} executed patches, {r['n_families']} families, " + ("trained on the 10 original families, tested on 10 unseen ones" if a.new_families else "leave-families-out") + f"; base rate resolved {r['base_rate_resolved']:.3f}\n")
    print("AUPRC (resolved):   " + "   ".join(f"{k} {f(v)}" for k, v in r["auprc_resolved"].items()))
    print(f"B8 - B7:            {f(r['B8_minus_B7'])}\nB8 - B8-shuffled:   {f(r['B8_minus_B8-shuffled'])}")
    print("contract choice:    " + "   ".join(f"{k} {f(v)}" for k, v in r["contract_choice_accuracy"].items()))
    print("\nB8 per held-out family (threshold 0.5):")
    print(f"{'family':11s} {'prefers right contract':>23s} {'accepts correct':>16s} {'accepts wrong-contract':>23s}")
    for fam, d in r["per_family_B8"].items():
        print(f"{fam:11s} {d['contract_choice']:23.3f} {d['accepts_correct']:16.3f} {d['accepts_wrong_contract']:23.3f}")
    print("\ngate operating points (accept when P(resolved) >= t):")
    print(f"{'model':5s} {'t':>4s} {'accepted':>8s} {'precision':>9s} {'recall':>7s} {'accepts correct':>16s} {'accepts wrong-contract':>23s}")
    for m, by_t in r["gate"].items():
        for t, g in by_t.items():
            o = g["by_origin"]
            print(f"{m:5s} {t:>4s} {g['accepted']:8d} {g['accept_precision']:9.3f} {g['accept_recall']:7.3f} "
                  f"{1 - o['reference_own']['flag_rate']:16.3f} {1 - o['reference_other']['flag_rate']:23.3f}")


def cmd_demo(a) -> None:
    try:
        from contractbench import load_pairs, make_task, materialize
    except ImportError:
        sys.exit("demo needs the ContractBench package: pip install -e ../contractbench (or set PYTHONPATH)")
    from .model import FAMILIES
    if a.family not in FAMILIES:
        sys.exit(f"family must be one of the interventions' families: {FAMILIES}")
    print(f"Training the gate WITHOUT family '{a.family}' (leave-family-out), so every example below is unseen.\n")
    model = train_full(exclude_families=[a.family])
    interventions = {}
    with gzip.open(ARTIFACTS / "interventions.jsonl.gz", "rt", encoding="utf-8") as f:
        for line in f:
            r = json.loads(line)
            if r["origin"] in ("reference_own", "reference_other", "noop"):
                interventions[(r["task_id"], r["origin"])] = r
    pairs = load_pairs()
    pid = next(p for p, r in pairs.items() if r["family"] == a.family)
    rec = pairs[pid]
    for v in (0, 1):
        task = make_task(rec, v)
        print(f"=== task {task.task_id}   date {task.cutoff}\n    issue: {task.issue}")
        for origin, label in (("reference_own", "fix that follows the contract in force"),
                              ("reference_other", "fix that follows the OTHER (wrong) contract"), ("noop", "no-op patch")):
            with tempfile.TemporaryDirectory() as d:
                materialize(rec, v, Path(d))
                verdict = assess(d, task.cutoff, rec["target_file"], rec["func"], new_src=interventions[(task.task_id, origin)]["src"], model=model)
            print(f"\n  [{label}]")
            _show(verdict)
        print()


def main(argv: list[str] | None = None) -> None:
    ap = argparse.ArgumentParser(prog="contractgate", description=__doc__)
    sub = ap.add_subparsers(dest="cmd", required=True)
    s = sub.add_parser("assess", help="score one candidate patch against the contract in force")
    s.add_argument("--repo", required=True); s.add_argument("--date", required=True, help="task date, ISO (YYYY-MM-DD)")
    s.add_argument("--file", required=True, help="patched file, relative to --repo"); s.add_argument("--func", required=True)
    g = s.add_mutually_exclusive_group(required=True)
    g.add_argument("--new-file", help="path to the full new text of the file"); g.add_argument("--patch", help="path to SEARCH/REPLACE blocks")
    s.add_argument("--threshold", type=float, default=0.5); s.add_argument("--json", action="store_true"); s.set_defaults(fn=cmd_assess)
    d = sub.add_parser("demo", help="worked example on a held-out family"); d.add_argument("--family", default="expiry"); d.set_defaults(fn=cmd_demo)
    e = sub.add_parser("evaluate", help="leave-families-out evaluation (about 20 s)"); e.add_argument("--out"); e.add_argument("--new-families", action="store_true", help="out-of-family test on the 10 added families"); e.set_defaults(fn=cmd_evaluate)
    sub.add_parser("train", help="fit on all families and save artifacts/model.joblib").set_defaults(fn=cmd_train)
    args = ap.parse_args(argv)
    args.fn(args)


if __name__ == "__main__":
    main()
