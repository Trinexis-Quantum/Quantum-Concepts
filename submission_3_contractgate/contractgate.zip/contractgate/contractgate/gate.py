"""The wrong-contract risk gate: time-valid contract evidence + code graph + C3-GWM, before any test is run.

Pipeline for one candidate patch:
 1. build the code graph and ADR chunks of the repository snapshot (``graph.build_kg``);
 2. keep only ADRs that apply to the patched file/function and are dated on or before the task date, and mark
    the ones already superseded by a later (still on-time) ADR  -> contract in force vs superseded contract;
 3. count callers/tests of the patched symbol in the graph;
 4. let the world model predict P(patch resolves the task) from the diff and the contract text;
 5. accept, flag, or abstain (no contract evidence for this symbol).
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from pathlib import Path

from .features import GBDTWorldModel, Sample, _diff_lines, _nums
from .graph import DocChunk, build_kg
from .model import load_model

APPLIES_RE = re.compile(r"Applies to:\s*`([^`]+)`(?:\s*\(`([^`]+)`\))?")
BLOCK_RE = re.compile(r"<<<<<<< SEARCH:?[ \t]*(?P<path>[^\n]*)\n(?P<old>.*?)\n?=======\n(?P<new>.*?)\n?>>>>>>> REPLACE", re.DOTALL)


@dataclass
class ContractEvidence:
    adr_id: str
    date: str | None
    path: str
    status: str            # "in_force" | "superseded"
    summary: str


@dataclass
class Verdict:
    decision: str          # "accept" | "flag" | "abstain"
    p_resolved: float | None
    p_own_pass: float | None
    p_inv_pass: float | None
    threshold: float
    contract_in_force: ContractEvidence | None
    superseded: list[ContractEvidence] = field(default_factory=list)
    reasons: list[str] = field(default_factory=list)

    def to_dict(self) -> dict:
        return {**self.__dict__, "contract_in_force": self.contract_in_force.__dict__ if self.contract_in_force else None,
                "superseded": [e.__dict__ for e in self.superseded]}


def _body(text: str) -> str:
    """ADR text without its header lines (title, date, scope), so ids and dates are not mistaken for contract values."""
    return " ".join(l.strip() for l in text.splitlines() if l.strip() and not l.startswith(("#", "Date:", "Applies to:")))


def _values(text: str) -> set[str]:
    """Numbers in an ADR body, ignoring references to other ADRs ("revises ADR-010")."""
    return _nums(re.sub(r"ADR-\d+", "", _body(text)))


def _summary(chunk: DocChunk) -> str:
    return _body(chunk.text)[:240]


def contracts_for(kg, task_date: str, target_file: str, func: str) -> tuple[DocChunk | None, list[DocChunk]]:
    """(contract in force, superseded contracts) for one symbol at ``task_date`` (ISO date); later ADRs are invisible."""
    kg.resolve_supersession(task_date)
    relevant = []
    for d in kg.docs:
        if not (d.doc_id.startswith("ADR-") and d.date and d.date <= task_date):
            continue
        m = APPLIES_RE.search(d.text)
        if m and m.group(1) == target_file and (not m.group(2) or m.group(2) == func):
            relevant.append(d)
    in_force = sorted((d for d in relevant if not d.superseded_by), key=lambda d: d.date)
    superseded = sorted((d for d in relevant if d.superseded_by), key=lambda d: d.date)
    return (in_force[-1] if in_force else None), superseded


def apply_blocks(text: str, patch: str) -> str:
    """Apply SEARCH/REPLACE blocks to one file's text; every SEARCH must match exactly once."""
    blocks = list(BLOCK_RE.finditer(patch))
    if not blocks:
        raise ValueError("no SEARCH/REPLACE blocks found")
    for m in blocks:
        if text.count(m["old"]) != 1:
            raise ValueError(f"SEARCH block matched {text.count(m['old'])} times")
        text = text.replace(m["old"], m["new"], 1)
    return text


def assess(repo: Path | str, task_date: str, target_file: str, func: str, new_src: str | None = None, patch: str | None = None,
           model: GBDTWorldModel | None = None, threshold: float = 0.5) -> Verdict:
    """Assess one candidate patch (full new file text in ``new_src`` or SEARCH/REPLACE blocks in ``patch``)."""
    repo = Path(repo)
    kg = build_kg(repo)
    gov, superseded = contracts_for(kg, task_date, target_file, func)
    if gov is None:
        return Verdict("abstain", None, None, None, threshold, None, [], [
            f"no dated ADR applies to {target_file}::{func} on or before {task_date}; the gate does not guess"])
    old_src = (repo / target_file).read_text(encoding="utf-8")
    if new_src is None:
        new_src = apply_blocks(old_src, patch or "")
    target = next((n for n, i in kg.symbols.items() if i["name"] == func and i["path"] == target_file), None)
    callers = kg.callers(target) if target else []
    tests = len({t for c in callers for t in kg.tests_of(c)} | set(kg.tests_of(target))) if target else 0
    other_text = "\n".join(d.text for d in superseded)
    sample = Sample("query", "query", old_src, new_src, func, gov.text, other_text, len(callers), tests, {})
    pred = (model or load_model()).predict([sample])
    p, p_own, p_inv = float(pred["resolved"][0]), float(pred["own_pass"][0]), float(pred["inv_pass"][0])

    added, _ = _diff_lines(old_src, new_src)
    added_nums = _nums("\n".join(added))
    gov_nums, other_nums = _values(gov.text), _values(" ".join(d.text for d in superseded))
    reasons = [f"contract in force on {task_date}: {gov.doc_id} ({gov.date})"]
    stale = sorted(added_nums & (other_nums - gov_nums))
    if stale:
        reasons.append(f"patch introduces values that appear only in the superseded contract: {stale}")
    missing = sorted(gov_nums - _nums(new_src))
    if missing:
        reasons.append(f"values from {gov.doc_id} that the patched file does not contain: {missing}")
    decision = "accept" if p >= threshold else "flag"
    return Verdict(decision, p, p_own, p_inv, threshold,
                   ContractEvidence(gov.doc_id, gov.date, gov.path, "in_force", _summary(gov)),
                   [ContractEvidence(d.doc_id, d.date, d.path, "superseded", _summary(d)) for d in superseded], reasons)
