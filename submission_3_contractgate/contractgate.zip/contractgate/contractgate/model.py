"""Training data, leave-families-out evaluation and persistence for the gate's world model."""
from __future__ import annotations

import gzip
import json
import random
from pathlib import Path

import numpy as np

from .features import HEADS, GBDTWorldModel, Sample, head_metrics

ARTIFACTS = Path(__file__).resolve().parent / "artifacts"
MODEL_PATH = ARTIFACTS / "model.joblib"
# The 10 families covered by the executed interventions (first 120 pairs of ContractBench), in the paper's order.
FAMILIES = ["expiry", "rounding", "pagination", "backoff", "bytes", "discount", "password", "email", "bizdays", "slug"]


def load_samples(artifacts: Path = ARTIFACTS) -> list[Sample]:
    """Executed interventions (6,480 candidate patches with real verifier outcomes) as model-ready samples."""
    ctx = json.load(open(artifacts / "contexts.json", encoding="utf-8"))
    out: list[Sample] = []
    with gzip.open(artifacts / "interventions.jsonl.gz", "rt", encoding="utf-8") as f:
        for line in f:
            r = json.loads(line)
            c = ctx[r["task_id"]]
            labels = {"own_pass": r["own_pass"], "inv_pass": r["inv_pass"], "resolved": int(r["own_pass"] and r["inv_pass"]),
                      "other_contract_pass": r["other_contract_pass"]}
            out.append(Sample(r["task_id"], c["family"], c["legacy"], r["src"], c["func"], c["gov"], c["other"],
                              c["callers"], c["tests"], labels, r["origin"]))
    return out


def shuffle_contracts(samples: list[Sample], seed: int = 0) -> list[Sample]:
    """Negative control: give every task the contract text of another task (breaks contract conditioning)."""
    rng = random.Random(seed)
    by_task = {s.task_id: s for s in samples}
    ids = sorted(by_task)
    perm = ids[:]
    rng.shuffle(perm)
    mapping = dict(zip(ids, perm))
    return [Sample(s.task_id, s.family, s.old_src, s.new_src, s.func, by_task[mapping[s.task_id]].gov_text,
                   by_task[mapping[s.task_id]].other_text, s.n_callers, s.n_tests, s.labels, s.origin, s.outcomes) for s in samples]


def make_model(name: str) -> GBDTWorldModel:
    """B7 = contract-blind (S+T); B8 = C3-GWM, contract-conditioned (S+T+C)."""
    return GBDTWorldModel({"B7": "ST", "B8": "STC"}[name])


def cv_predict(model_name: str, samples: list[Sample], n_folds: int = 5, eval_samples: list[Sample] | None = None) -> dict[str, np.ndarray]:
    """Leave-families-out predictions: the model never sees the family it predicts.

    ``eval_samples`` (same order) lets the negative control corrupt contracts at test time only.
    """
    folds = [FAMILIES[i::n_folds] for i in range(n_folds)]
    preds = {h: np.zeros(len(samples)) for h in HEADS}
    eval_samples = eval_samples or samples
    for fold in folds:
        tr = [i for i, s in enumerate(samples) if s.family not in fold]
        te = [i for i, s in enumerate(samples) if s.family in fold]
        out = make_model(model_name).fit([samples[i] for i in tr]).predict([eval_samples[i] for i in te])
        for h in HEADS:
            preds[h][te] = out[h]
    return preds


def cluster_bootstrap(values_by_cluster: dict[str, float], n: int = 2000, seed: int = 0) -> tuple[float, float, float]:
    """Mean and 95% CI of per-cluster values, resampling clusters (families)."""
    rng = np.random.default_rng(seed)
    vals = np.array(list(values_by_cluster.values()))
    boots = [rng.choice(vals, len(vals)).mean() for _ in range(n)]
    return float(vals.mean()), float(np.percentile(boots, 2.5)), float(np.percentile(boots, 97.5))


def auprc_by_family(samples: list[Sample], preds: dict[str, np.ndarray], head: str = "resolved", families: list[str] | None = None) -> dict[str, float]:
    out = {}
    for fam in families or FAMILIES:
        idx = [i for i, s in enumerate(samples) if s.family == fam]
        y = np.array([samples[i].labels[head] for i in idx])
        m = head_metrics(y, preds[head][idx])["auprc"]
        if not np.isnan(m):
            out[fam] = m
    return out


def gate_report(samples: list[Sample], p_resolved: np.ndarray, threshold: float = 0.5) -> dict:
    """What the gate does at one operating point: flag a patch when P(resolved) < threshold.

    Reported per candidate origin so that the headline case (the other contract's reference patch,
    i.e. a wrong-contract patch that is otherwise a clean correct fix) is not hidden inside the mutants.
    """
    flag = p_resolved < threshold
    y = np.array([s.labels["resolved"] for s in samples])
    by_origin: dict[str, dict] = {}
    for kind in ("reference_own", "reference_other", "noop", "mutants"):
        idx = [i for i, s in enumerate(samples) if (s.origin.startswith("mutant") if kind == "mutants" else s.origin == kind)]
        by_origin[kind] = {"n": len(idx), "flag_rate": float(flag[idx].mean()), "resolved_rate": float(y[idx].mean())}
    accept = ~flag
    n_acc = int(accept.sum())
    return {"threshold": threshold, "by_origin": by_origin,
            "accepted": n_acc, "accept_precision": float(y[accept].mean()) if n_acc else float("nan"),
            "accept_recall": float((accept & (y == 1)).sum() / max(1, int((y == 1).sum()))),
            "base_rate_resolved": float(y.mean()), "n": len(samples)}


def contract_choice_accuracy(samples: list[Sample], p_resolved: np.ndarray) -> dict[str, float]:
    """Per family: how often the gate scores the own-contract reference patch above the other contract's reference patch.

    Both are clean, plausible fixes for the same task; only the contract in force tells them apart. Ties count 0.5.
    """
    own: dict[str, int] = {}
    other: dict[str, int] = {}
    for i, s in enumerate(samples):
        if s.origin == "reference_own":
            own[s.task_id] = i
        elif s.origin == "reference_other":
            other[s.task_id] = i
    by_fam: dict[str, list[float]] = {}
    for tid in own.keys() & other.keys():
        a, b = p_resolved[own[tid]], p_resolved[other[tid]]
        by_fam.setdefault(samples[own[tid]].family, []).append(1.0 if a > b else 0.5 if a == b else 0.0)
    return {f: float(np.mean(v)) for f, v in by_fam.items()}


NEW_FAMILIES = ["jsondump", "urlquote", "casefold", "isoday", "wordwrap", "shellquote", "percentile", "moneyfmt", "pairup", "duration"]


def load_new_samples(artifacts: Path = ARTIFACTS) -> list[Sample]:
    """Executed patches for the 10 families that were never used for training or cross-validation."""
    ctx = json.load(open(artifacts / "new_contexts.json", encoding="utf-8"))
    out: list[Sample] = []
    with gzip.open(artifacts / "new_family_interventions.jsonl.gz", "rt", encoding="utf-8") as f:
        for line in f:
            r = json.loads(line)
            c = ctx[r["task_id"]]
            labels = {"own_pass": r["own_pass"], "inv_pass": r["inv_pass"], "resolved": int(r["own_pass"] and r["inv_pass"]),
                      "other_contract_pass": r["other_contract_pass"]}
            out.append(Sample(r["task_id"], c["family"], c["legacy"], r["src"], c["func"], c["gov"], c["other"],
                              c["callers"], c["tests"], labels, r["origin"]))
    return out


def _summarize(samples: list[Sample], runs: dict[str, dict], families: list[str], n_boot: int) -> dict:
    out: dict = {"n_samples": len(samples), "n_families": len(families),
                 "base_rate_resolved": float(np.mean([s.labels["resolved"] for s in samples])), "auprc_resolved": {}}
    per_fam = {}
    for name, preds in runs.items():
        per_fam[name] = auprc_by_family(samples, preds, families=families)
        mean, lo, hi = cluster_bootstrap(per_fam[name], n_boot)
        out["auprc_resolved"][name] = {"mean": mean, "lo": lo, "hi": hi}
    for name in ("B7", "B8-shuffled"):
        common = per_fam["B8"].keys() & per_fam[name].keys()
        mean, lo, hi = cluster_bootstrap({f: per_fam["B8"][f] - per_fam[name][f] for f in common}, n_boot)
        out[f"B8_minus_{name}"] = {"mean": mean, "lo": lo, "hi": hi}
    out["contract_choice_accuracy"] = {}
    for name, preds in runs.items():
        mean, lo, hi = cluster_bootstrap(contract_choice_accuracy(samples, preds["resolved"]), n_boot)
        out["contract_choice_accuracy"][name] = {"mean": mean, "lo": lo, "hi": hi}
    p8 = runs["B8"]["resolved"]
    choice = contract_choice_accuracy(samples, p8)
    out["per_family_B8"] = {}
    for fam in families:
        idx = [i for i, s in enumerate(samples) if s.family == fam]
        own = [i for i in idx if samples[i].origin == "reference_own"]
        oth = [i for i in idx if samples[i].origin == "reference_other"]
        out["per_family_B8"][fam] = {"contract_choice": choice[fam], "accepts_correct": float((p8[own] >= 0.5).mean()),
                                     "accepts_wrong_contract": float((p8[oth] >= 0.5).mean())}
    out["gate"] = {name: {str(t): gate_report(samples, runs[name]["resolved"], t) for t in (0.3, 0.5, 0.7)} for name in ("B7", "B8")}
    return out


def evaluate(n_boot: int = 2000) -> dict:
    """Leave-families-out comparison reproducing the paper's world-model test (H2) with its negative control."""
    samples = load_samples()
    runs = {"B7": cv_predict("B7", samples), "B8": cv_predict("B8", samples),
            "B8-shuffled": cv_predict("B8", samples, eval_samples=shuffle_contracts(samples))}
    return _summarize(samples, runs, FAMILIES, n_boot)


def evaluate_new_families(n_boot: int = 2000) -> dict:
    """Train on the 10 original families, test on 10 families that no model or hyper-parameter ever saw."""
    train, test = load_samples(), load_new_samples()
    b7, b8 = make_model("B7").fit(train), make_model("B8").fit(train)
    runs = {"B7": b7.predict(test), "B8": b8.predict(test), "B8-shuffled": b8.predict(shuffle_contracts(test))}
    return _summarize(test, runs, NEW_FAMILIES, n_boot)


def train_full(exclude_families: list[str] | None = None) -> GBDTWorldModel:
    """Fit B8 on all (or all but the excluded) families of executed interventions."""
    samples = [s for s in load_samples() if s.family not in (exclude_families or [])]
    return make_model("B8").fit(samples)


def save_model(model: GBDTWorldModel, path: Path = MODEL_PATH) -> None:
    import joblib
    import sklearn
    joblib.dump({"model": model, "sklearn": sklearn.__version__}, path)


def load_model(path: Path = MODEL_PATH) -> GBDTWorldModel:
    """Load the shipped model; retrain from the shipped interventions if it is missing or was built with another scikit-learn."""
    import joblib
    import sklearn
    if path.exists():
        blob = joblib.load(path)
        if blob.get("sklearn") == sklearn.__version__:
            return blob["model"]
    return train_full()
