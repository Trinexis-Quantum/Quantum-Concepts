"""Features and the C3-GWM world model (B8), copied verbatim from the paper repository.

Sources: `coevo/worldmodel.py` (Sample, structural/text/contract features, GBDTWorldModel, metrics) and `coevo/retrieval.py`
(`tokenize`). Only the module layout changed. Groups: S structural, T hashed tokens of added lines, C contract-conditioned.
B7 = groups "ST" (contract-blind), B8 = groups "STC" (contract-conditioned).
"""
from __future__ import annotations

import ast
import difflib
import math
import re
from dataclasses import dataclass

import numpy as np
from sklearn.ensemble import HistGradientBoostingClassifier
from sklearn.feature_extraction.text import HashingVectorizer
from sklearn.metrics import average_precision_score, brier_score_loss, roc_auc_score

_TOKEN = re.compile(r"[A-Za-z][A-Za-z0-9]+")
STOP = set("the a an of to in is it and or for on with that this be as are by at not from if we our i you was were has have".split())


def tokenize(text: str) -> list[str]:
    """Lower-cased word tokens with snake_case / camelCase identifiers split into parts."""
    out: list[str] = []
    for tok in _TOKEN.findall(text):
        parts = re.sub(r"([a-z0-9])([A-Z])", r"\1 \2", tok).lower().split()
        out += [p for p in parts if p not in STOP and len(p) > 1]
    return out

NUM_RE = re.compile(r"(?<![\w.])\d+(?:\.\d+)?")
HEADS = ("own_pass", "inv_pass", "resolved")
_HASH = HashingVectorizer(n_features=64, alternate_sign=False, norm=None, analyzer="word", token_pattern=r"[A-Za-z_][A-Za-z0-9_]+")


@dataclass
class Sample:
    """One executed intervention with everything the models are allowed to see."""

    task_id: str
    family: str
    old_src: str            # base version of the target file
    new_src: str            # candidate version
    func: str               # target function name
    gov_text: str           # text of the contract in force on the task date
    other_text: str         # text of the superseded / other-version contract (used only for diagnostics)
    n_callers: int
    n_tests: int
    labels: dict            # head -> 0/1 (from execution)
    origin: str = ""
    outcomes: dict | None = None   # executed per-test status (test id -> pass/fail); used only as training labels by the graph-delta head


def _diff_lines(old: str, new: str) -> tuple[list[str], list[str]]:
    added, removed = [], []
    for line in difflib.unified_diff(old.splitlines(), new.splitlines(), lineterm="", n=0):
        if line.startswith("+") and not line.startswith("+++"):
            added.append(line[1:])
        elif line.startswith("-") and not line.startswith("---"):
            removed.append(line[1:])
    return added, removed


def _nums(text: str) -> set[str]:
    return set(NUM_RE.findall(text))


def structural_features(s: Sample) -> list[float]:
    """Contract-blind graph/diff features (group S)."""
    added, removed = _diff_lines(s.old_src, s.new_src)
    a_txt, r_txt = "\n".join(added), "\n".join(removed)
    sig_changed = float(any(l.lstrip().startswith("def ") for l in added + removed))
    cmp_ops = lambda t: len(re.findall(r"[<>]=?|==|!=", t))  # noqa: E731
    try:
        ast.parse(s.new_src)
        parses = 1.0
    except SyntaxError:
        parses = 0.0
    return [len(added), len(removed), sig_changed, len(_nums(a_txt)), len(_nums(r_txt)), len(_nums(a_txt) - _nums(r_txt)),
            cmp_ops(a_txt) - cmp_ops(r_txt), len(re.findall(r"""['"]""", a_txt)) / 2, float(s.n_callers), float(s.n_tests),
            parses, math.log1p(len(s.new_src))]


def text_features(s: Sample) -> np.ndarray:
    """Hashed bag-of-tokens of the ADDED lines (group T)."""
    added, _ = _diff_lines(s.old_src, s.new_src)
    return _HASH.transform([" ".join(added)]).toarray()[0]


def _tok_set(text: str) -> set[str]:
    return set(tokenize(text))


def contract_features(s: Sample) -> list[float]:
    """Features comparing the patched function with the contract in force (group C)."""
    added, _ = _diff_lines(s.old_src, s.new_src)
    a_txt = "\n".join(added)
    gov_nums, other_nums = _nums(s.gov_text), _nums(s.other_text)
    new_nums = _nums(s.new_src)
    added_nums = _nums(a_txt)
    gov_tok, other_tok = _tok_set(s.gov_text), _tok_set(s.other_text)
    new_tok, add_tok = _tok_set(s.new_src), _tok_set(a_txt)

    def frac(a: set, b: set) -> float:
        return len(a & b) / len(a) if a else 0.0

    return [
        frac(gov_nums, new_nums),                 # share of contract numbers realised in the patched code
        frac(added_nums, gov_nums),               # share of newly introduced numbers justified by the contract
        frac(added_nums, other_nums - gov_nums),  # numbers that only the OTHER contract mentions (wrong-contract signal)
        frac(gov_tok, new_tok), frac(add_tok, gov_tok),
        frac(add_tok, other_tok - gov_tok),
        float(len(gov_nums - new_nums)),          # contract numbers still missing from the code
    ]


def featurize(samples: list[Sample], groups: str) -> np.ndarray:
    """Stack the requested feature groups ('S', 'ST', 'STC')."""
    rows = []
    for s in samples:
        row: list[float] = structural_features(s)
        if "T" in groups:
            row += list(text_features(s))
        if "C" in groups:
            row += contract_features(s)
        rows.append(row)
    return np.asarray(rows, dtype=float)


# ----------------------------------------------------------------------------- models
class GBDTWorldModel:
    """One HistGradientBoosting classifier per outcome head (multi-head, shared features)."""

    def __init__(self, groups: str, seed: int = 0):
        self.groups, self.seed = groups, seed
        self.models: dict[str, HistGradientBoostingClassifier | float] = {}

    def fit(self, samples: list[Sample]) -> "GBDTWorldModel":
        X = featurize(samples, self.groups)
        for head in HEADS:
            y = np.array([s.labels[head] for s in samples])
            if len(set(y)) < 2:
                self.models[head] = float(y.mean())
                continue
            self.models[head] = HistGradientBoostingClassifier(max_iter=120, learning_rate=0.08, max_depth=4,
                                                               l2_regularization=1.0, random_state=self.seed).fit(X, y)
        return self

    def predict(self, samples: list[Sample]) -> dict[str, np.ndarray]:
        X = featurize(samples, self.groups)
        out = {}
        for head, m in self.models.items():
            out[head] = np.full(len(samples), m) if isinstance(m, float) else m.predict_proba(X)[:, 1]
        return out


def expected_calibration_error(y: np.ndarray, p: np.ndarray, bins: int = 10) -> float:
    """Equal-width ECE."""
    edges = np.linspace(0, 1, bins + 1)
    ece = 0.0
    for lo, hi in zip(edges[:-1], edges[1:]):
        mask = (p >= lo) & (p < hi if hi < 1 else p <= hi)
        if mask.any():
            ece += mask.mean() * abs(y[mask].mean() - p[mask].mean())
    return float(ece)


def head_metrics(y: np.ndarray, p: np.ndarray) -> dict[str, float]:
    """AUPRC / AUROC / Brier / ECE for one head (NaN when only one class is present)."""
    y, p = np.asarray(y), np.clip(np.asarray(p, float), 0, 1)
    both = len(set(y)) == 2
    return {"auprc": float(average_precision_score(y, p)) if both else float("nan"),
            "auroc": float(roc_auc_score(y, p)) if both else float("nan"),
            "brier": float(brier_score_loss(y, p)), "ece": expected_calibration_error(y, p),
            "base_rate": float(y.mean())}
