"""Time-versioned development knowledge graph (vendored unchanged from the paper repository `coevo/kg.py`, except for the is_test_path import)

Original docstring: Time-versioned development knowledge graph (deterministic extraction, no LLM facts).

Node types:  module, class, function, test, doc
Relations:   DEFINES, IMPORTS, CALLS, TESTS, MENTIONS, SUPERSEDES

Every document chunk carries ``date`` and ``superseded_by`` so retrieval can be made
*time-valid* (drop anything newer than the task cutoff, mark superseded contracts).
Edges extracted from code are ``observed`` facts; doc->code MENTIONS are ``document-claimed``.
"""
from __future__ import annotations

import ast
import re
from dataclasses import dataclass, field
from pathlib import Path

import networkx as nx

TEST_PATH_RE = re.compile(r"(^|/)(tests?|testing)/|(^|/)test_[^/]*\.py$|_test\.py$|(^|/)conftest\.py$")


def is_test_path(path: str) -> bool:
    return bool(TEST_PATH_RE.search(path))

DOC_PATH_RE = re.compile(r"(^|/)(README|CHANGE|CHANGES|CHANGELOG|HISTORY|NEWS)[^/]*$|(^|/)docs?/.*\.(md|rst|txt)$", re.I)
SUPERSEDE_RE = re.compile(r"\b(?:revises|supersedes|replaces|amends)\s+(ADR-\d+)", re.I)
ADR_HEAD_RE = re.compile(r"^#\s*(ADR-\d+)\b[^\n]*", re.M)
DATE_RE = re.compile(r"^Date:\s*(\d{4}-\d{2}-\d{2})", re.M)
MAX_PY_BYTES = 250_000


@dataclass
class DocChunk:
    """One retrievable documentation chunk with temporal metadata."""

    doc_id: str
    path: str
    heading: str
    text: str
    date: str | None = None           # ISO date if the document states one
    supersedes: list[str] = field(default_factory=list)
    superseded_by: str | None = None  # filled in by ``DevKG.resolve_supersession``


@dataclass
class DevKG:
    """Container for the code graph, document chunks and file contents of one snapshot."""

    root: Path
    graph: nx.MultiDiGraph = field(default_factory=nx.MultiDiGraph)
    docs: list[DocChunk] = field(default_factory=list)
    sources: dict[str, str] = field(default_factory=dict)       # path -> text (python files)
    symbols: dict[str, dict] = field(default_factory=dict)      # node id -> {path, name, lineno, end, kind}

    # ------------------------------------------------------------------ queries
    def callers(self, node: str) -> list[str]:
        return [u for u, _, d in self.graph.in_edges(node, data=True) if d.get("rel") == "CALLS"]

    def callees(self, node: str) -> list[str]:
        return [v for _, v, d in self.graph.out_edges(node, data=True) if d.get("rel") == "CALLS"]

    def tests_of(self, node: str) -> list[str]:
        return [u for u, _, d in self.graph.in_edges(node, data=True) if d.get("rel") == "TESTS"]

    def resolve_supersession(self, cutoff: str | None) -> None:
        """Mark chunks superseded by a document dated <= cutoff (time-valid view)."""
        by_id = {d.doc_id: d for d in self.docs if d.doc_id.startswith("ADR-")}
        for d in self.docs:
            d.superseded_by = None
        for d in by_id.values():
            if cutoff and d.date and d.date > cutoff:
                continue
            for old in d.supersedes:
                if old in by_id:
                    by_id[old].superseded_by = d.doc_id

    def node_source(self, node: str) -> str:
        info = self.symbols.get(node)
        if not info:
            return ""
        lines = self.sources.get(info["path"], "").splitlines()
        return "\n".join(lines[info["lineno"] - 1: info["end"]])


def _qualnames(tree: ast.AST):
    """Yield (qualname, node, kind) for functions/classes of a module."""

    def walk(body, prefix):
        for n in body:
            if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef)):
                yield prefix + n.name, n, "function"
                yield from walk(n.body, prefix + n.name + ".")
            elif isinstance(n, ast.ClassDef):
                yield prefix + n.name, n, "class"
                yield from walk(n.body, prefix + n.name + ".")

    yield from walk(tree.body, "")


def _call_names(fn: ast.AST) -> set[str]:
    names: set[str] = set()
    for n in ast.walk(fn):
        if isinstance(n, ast.Call):
            f = n.func
            if isinstance(f, ast.Name):
                names.add(f.id)
            elif isinstance(f, ast.Attribute):
                names.add(f.attr)
    return names


def _chunk_doc(path: str, text: str) -> list[DocChunk]:
    """Split a doc into heading-delimited chunks; ADRs become a single chunk with id/date/links."""
    head = ADR_HEAD_RE.search(text)
    if head and "adr" in path.lower():
        date = DATE_RE.search(text)
        return [DocChunk(head.group(1), path, head.group(0).lstrip("# ").strip(), text.strip(),
                         date.group(1) if date else None, [m.upper() for m in SUPERSEDE_RE.findall(text)])]
    parts = re.split(r"(?m)^(?=#{1,3}\s|[^\n]+\n(?:={3,}|-{3,})\s*$)", text)
    chunks = []
    for i, part in enumerate(p for p in parts if p.strip()):
        heading = part.strip().splitlines()[0][:80]
        # keep chunks bounded so retrieval returns focused evidence
        for j in range(0, len(part), 1800):
            chunks.append(DocChunk(f"{path}#{i}.{j // 1800}", path, heading, part[j:j + 1800].strip()))
    return chunks


def build_kg(root: Path) -> DevKG:
    """Extract the code graph and document chunks of a snapshot directory."""
    kg = DevKG(root=root)
    g = kg.graph
    by_name: dict[str, list[str]] = {}
    call_sets: dict[str, set[str]] = {}
    for path in sorted(root.rglob("*")):
        if not path.is_file() or any(part.startswith(".") for part in path.relative_to(root).parts):
            continue
        rel = str(path.relative_to(root))
        if path.suffix == ".py" and path.stat().st_size <= MAX_PY_BYTES:
            text = path.read_text(encoding="utf-8", errors="ignore")
            try:
                tree = ast.parse(text)
            except (SyntaxError, ValueError):
                continue
            kg.sources[rel] = text
            mod = f"module:{rel}"
            g.add_node(mod, type="module", path=rel)
            for imp in (n for n in ast.walk(tree) if isinstance(n, (ast.Import, ast.ImportFrom))):
                names = [a.name for a in imp.names] if isinstance(imp, ast.Import) else [imp.module or ""]
                for name in names:
                    g.add_edge(mod, f"import:{name.split('.')[0]}", rel="IMPORTS", provenance="observed")
            for qual, node, kind in _qualnames(tree):
                is_test = is_test_path(rel) and kind == "function" and qual.split(".")[-1].startswith("test")
                nid = f"{'test' if is_test else kind}:{rel}::{qual}"
                g.add_node(nid, type="test" if is_test else kind, path=rel, name=qual)
                g.add_edge(mod, nid, rel="DEFINES", provenance="observed")
                kg.symbols[nid] = {"path": rel, "name": qual, "lineno": node.lineno,
                                   "end": getattr(node, "end_lineno", node.lineno), "kind": kind}
                if kind == "function":
                    by_name.setdefault(qual.split(".")[-1], []).append(nid)
                    call_sets[nid] = _call_names(node)
        elif DOC_PATH_RE.search(rel) and path.suffix.lower() in (".md", ".rst", ".txt", ""):
            try:
                text = path.read_text(encoding="utf-8")
            except UnicodeDecodeError:
                continue
            for chunk in _chunk_doc(rel, text):
                kg.docs.append(chunk)
                g.add_node(f"doc:{chunk.doc_id}", type="doc", path=rel, date=chunk.date)
    for src, called in call_sets.items():
        for name in called:
            targets = by_name.get(name, [])
            if 0 < len(targets) <= 3:
                for tgt in targets:
                    if tgt == src:
                        continue
                    g.add_edge(src, tgt, rel="CALLS", provenance="observed")
                    if g.nodes[src].get("type") == "test":
                        g.add_edge(src, tgt, rel="TESTS", provenance="observed")
    identifiers = {k for k in by_name if len(k) >= 5}
    for chunk in kg.docs:
        for ident in set(re.findall(r"[A-Za-z_][A-Za-z0-9_]{4,}", chunk.text)) & identifiers:
            for tgt in by_name[ident]:
                g.add_edge(f"doc:{chunk.doc_id}", tgt, rel="MENTIONS", provenance="document-claimed")
    for chunk in kg.docs:
        for old in chunk.supersedes:
            g.add_edge(f"doc:{chunk.doc_id}", f"doc:{old}", rel="SUPERSEDES", provenance="document-claimed")
    return kg
